#ifndef COMPUTEPI_H
#define COMPUTEPI_H

long double getPi(int n);

#endif