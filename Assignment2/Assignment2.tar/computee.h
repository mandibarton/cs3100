#ifndef COMPUTEE_H
#define COMPUTEE_H

double getValueOfe(int cur, int iters, double f, double v);

#endif