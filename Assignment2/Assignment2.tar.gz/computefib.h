#ifndef COMPUTEFIB_H
#define COMPUTEFIB_H

int fibonacci(int n);


#endif